package bo;

import model.Category;

import java.util.List;

public interface CategoryBO {
    List<Category> findAllCategory();
}
